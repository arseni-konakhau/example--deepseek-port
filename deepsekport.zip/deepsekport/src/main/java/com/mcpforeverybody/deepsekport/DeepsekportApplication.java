package com.mcpforeverybody.deepsekport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeepsekportApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeepsekportApplication.class, args);
	}

}
